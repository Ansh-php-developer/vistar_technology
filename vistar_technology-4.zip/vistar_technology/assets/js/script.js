document.addEventListener('DOMContentLoaded', function () {
  var btn = document.querySelector('.menu-btn'), nav = document.querySelector('.nav');
  if (btn && nav) btn.addEventListener('click', function () {
    var open = nav.classList.toggle('open'); btn.setAttribute('aria-expanded', open);
  });
  document.querySelectorAll('form[data-confirm]').forEach(function (f) {
    f.addEventListener('submit', function (e) { if (!confirm(f.dataset.confirm)) e.preventDefault(); });
  });
  document.querySelectorAll('select[data-autosubmit]').forEach(function (s) {
    s.addEventListener('change', function () { s.form.submit(); });
  });
});

// Flip cards: tap to flip on touch screens (mouse devices use hover)
(function () {
  if (window.matchMedia && window.matchMedia('(hover:hover)').matches) return;
  document.addEventListener('click', function (ev) {
    var card = ev.target.closest && ev.target.closest('.flipcard');
    document.querySelectorAll('.flipcard.on').forEach(function (c) { if (c !== card) c.classList.remove('on'); });
    if (card && !ev.target.closest('a')) card.classList.toggle('on');
  });
})();
